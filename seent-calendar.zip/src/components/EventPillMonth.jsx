// EventPillMonth.jsx
// CACHE BUST v57 - SYNTHETIC MOUSE DOWN FIX (Full Drop-in)
import React from "react";

// Utility: clamp text to N lines using CSS-only
const clampStyle = (lines) => ({
  display: "-webkit-box",
  WebkitBoxOrient: "vertical",
  overflow: "hidden",
  WebkitLineClamp: lines,
  wordBreak: "break-word",
});

export default function EventPillMonth({ ev, style, className, onOpenEditor }) {
  const ref = React.useRef(null);

  // ... (style definitions remain)
  const titleStyle = { 
    fontWeight: 700, 
    fontSize: "12px",
    lineHeight: "1.2",
    marginBottom: "2px",
    ...clampStyle(1) 
  };
  
  const metaStyle = { 
    opacity: 0.9, 
    fontSize: "11px", 
    lineHeight: "1.2",
    marginBottom: "2px",
    ...clampStyle(1) 
  };
  
  const notesStyle = { 
    opacity: 0.8, 
    fontSize: "11px", 
    fontStyle: "italic",
    lineHeight: "1.1",
    ...clampStyle(2) 
  };

  // Safe data extraction
  const safeString = (val) => {
    if (!val) return "";
    if (typeof val === "string") return val;
    if (val.name) return val.name;
    return String(val);
  };

  const wip = safeString(ev.wipManager);
  const ins = safeString(ev.installer);
  const own = safeString(ev.caseOwner);
  const line2 = [wip, ins, own].filter(Boolean).join(" | ");

  // Container Style: 
  const containerStyle = {
    ...style,
    width: "100%",
    height: "100%",
    background: ev.colour || "#3b82f6",
    color: "#fff",
    padding: "4px 6px",
    borderRadius: "4px",
    cursor: "pointer",
    display: "flex",
    flexDirection: "column",
    justifyContent: "flex-start",
    boxSizing: "border-box",
    overflow: "hidden",
    boxShadow: "0 1px 2px rgba(0,0,0,0.2)",
    position: "relative" 
  };

  // --- CRITICAL FIX: Attach native event listener ---
  React.useEffect(() => {
    const node = ref.current;
    if (!node || !onOpenEditor) return;

    const handleMouseDown = (e) => {
        e.stopPropagation();
        e.stopImmediatePropagation();
        onOpenEditor(ev, { clientY: e.clientY, clientX: e.clientX });
    };

    node.addEventListener('mousedown', handleMouseDown);

    return () => {
        node.removeEventListener('mousedown', handleMouseDown);
    };
  }, [ev, onOpenEditor]);

  return (
    <div 
      ref={ref}
      className={`event-pill-month ${ev.isManual ? "event-pill--manual" : ""}`}
      style={{...containerStyle, cursor: 'pointer'}} // Enforce pointer cursor
      title={ev.title}
      // onClick REMOVED!
    >
      {/* Title */}
      <div style={titleStyle}>
        {ev.title || "Untitled"}
      </div>

      {/* Meta Info */}
      {line2 && <div style={metaStyle}>{line2}</div>}

      {/* Notes */}
      {ev.pmNotes && <div style={notesStyle}>{ev.pmNotes}</div>}
    </div>
  );
}